#include "ninetynine.h"

void testbed() {

	ninetynine a;
	a.displayPoem();

}

int main() {

	testbed();

	return 0;

}