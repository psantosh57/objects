#include "p1.h"

void testbed() {

	p1 a;
	a.print_usa();
	a.a_power_b();
	a.print_n_n2_n3();
	a.two_power_n();
	a.a1();
	a.a2();
	a.a3();
	a.a4();
	
}

int main() {

	testbed();


	return 0;
}