#include "../util/util.h"

#ifndef NINETYNINE_H
#define NINETYNINE_H

class ninetynine {


public : 

	void displayPoem();

private:

};

#endif