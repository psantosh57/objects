#pragma once

#ifndef TEMPERATURE_H
#define TEMPERATURE_H

#include "../util/util.h"

class temperature {

public:

	double fToC(double);
	double cToF(double);

private:

};

#endif