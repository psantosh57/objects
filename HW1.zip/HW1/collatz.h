#pragma once

#ifndef COLLATZ_H
#define COLLATZ_H

#include "../util/util.h"

class collatz {

public:
	//Argument "step" provided to count number of steps required to arrive at 1 for the corressponding number
	void collatzConjecture(int n, int step);

private:

};

#endif